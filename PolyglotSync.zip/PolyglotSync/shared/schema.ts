import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  learningStreak: integer("learning_streak").default(0),
  totalGamesLearned: integer("total_games_learned").default(0),
  totalTutorialsCompleted: integer("total_tutorials_completed").default(0),
});

export const games = pgTable("games", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  playerCount: text("player_count").notNull(),
  playTime: text("play_time").notNull(),
  difficulty: text("difficulty").notNull(), // Beginner, Intermediate, Advanced
  rating: integer("rating").default(0), // 1-5 stars
  imageUrl: text("image_url"),
  rules: text("rules").notNull(),
});

export const tutorials = pgTable("tutorials", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  stepNumber: integer("step_number").notNull(),
  content: text("content").notNull(),
  estimatedTime: integer("estimated_time").notNull(), // in minutes
  isQuickStart: boolean("is_quick_start").default(false),
});

export const userProgress = pgTable("user_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  gameId: varchar("game_id").notNull(),
  tutorialId: varchar("tutorial_id"),
  completed: boolean("completed").default(false),
  currentStep: integer("current_step").default(1),
  timeSpent: integer("time_spent").default(0), // in minutes
});

export const learningPaths = pgTable("learning_paths", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  gameIds: text("game_ids").array().notNull(),
  estimatedHours: integer("estimated_hours").notNull(),
  icon: text("icon").notNull(),
});

export const userGoals = pgTable("user_goals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  type: text("type").notNull(), // weekly, monthly
  target: integer("target").notNull(),
  current: integer("current").default(0),
  description: text("description").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  learningStreak: true,
  totalGamesLearned: true,
  totalTutorialsCompleted: true,
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  rating: true,
});

export const insertTutorialSchema = createInsertSchema(tutorials).omit({
  id: true,
});

export const insertUserProgressSchema = createInsertSchema(userProgress).omit({
  id: true,
});

export const insertLearningPathSchema = createInsertSchema(learningPaths).omit({
  id: true,
});

export const insertUserGoalSchema = createInsertSchema(userGoals).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;

export type Tutorial = typeof tutorials.$inferSelect;
export type InsertTutorial = z.infer<typeof insertTutorialSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

export type LearningPath = typeof learningPaths.$inferSelect;
export type InsertLearningPath = z.infer<typeof insertLearningPathSchema>;

export type UserGoal = typeof userGoals.$inferSelect;
export type InsertUserGoal = z.infer<typeof insertUserGoalSchema>;
