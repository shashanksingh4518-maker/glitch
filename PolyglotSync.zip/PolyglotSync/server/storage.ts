import { type User, type InsertUser, type Game, type InsertGame, type Tutorial, type InsertTutorial, type UserProgress, type InsertUserProgress, type LearningPath, type InsertLearningPath, type UserGoal, type InsertUserGoal } from "@shared/schema";
import { randomUUID } from "crypto";
import { DBStorage } from "./db-storage";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Game operations
  getAllGames(): Promise<Game[]>;
  getGame(id: string): Promise<Game | undefined>;
  searchGames(query: string): Promise<Game[]>;
  getGamesByCategory(category: string): Promise<Game[]>;
  createGame(game: InsertGame): Promise<Game>;

  // Tutorial operations
  getTutorialsByGameId(gameId: string): Promise<Tutorial[]>;
  getTutorial(id: string): Promise<Tutorial | undefined>;
  getQuickStartTutorials(): Promise<Tutorial[]>;
  createTutorial(tutorial: InsertTutorial): Promise<Tutorial>;

  // User progress operations
  getUserProgress(userId: string): Promise<UserProgress[]>;
  getUserGameProgress(userId: string, gameId: string): Promise<UserProgress[]>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: string, updates: Partial<UserProgress>): Promise<UserProgress | undefined>;

  // Learning paths
  getAllLearningPaths(): Promise<LearningPath[]>;
  getLearningPath(id: string): Promise<LearningPath | undefined>;
  createLearningPath(path: InsertLearningPath): Promise<LearningPath>;

  // User goals
  getUserGoals(userId: string): Promise<UserGoal[]>;
  createUserGoal(goal: InsertUserGoal): Promise<UserGoal>;
  updateUserGoal(id: string, updates: Partial<UserGoal>): Promise<UserGoal | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private games: Map<string, Game>;
  private tutorials: Map<string, Tutorial>;
  private userProgress: Map<string, UserProgress>;
  private learningPaths: Map<string, LearningPath>;
  private userGoals: Map<string, UserGoal>;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.tutorials = new Map();
    this.userProgress = new Map();
    this.learningPaths = new Map();
    this.userGoals = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize with some sample data for demonstration
    const sampleGames: Game[] = [
      {
        id: "1",
        title: "Wingspan",
        description: "Engine-building strategy game about birds",
        category: "Strategy",
        playerCount: "1-5 Players",
        playTime: "40-70 min",
        difficulty: "Intermediate",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1632501641765-e568d28b0015?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rules: "Wingspan is a competitive, medium-weight, card-driven, engine-building board game..."
      },
      {
        id: "2",
        title: "Ticket to Ride",
        description: "Railway-themed adventure board game",
        category: "Strategy",
        playerCount: "2-5 Players",
        playTime: "30-60 min",
        difficulty: "Beginner",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        rules: "Ticket to Ride is a railway-themed German-style board game..."
      },
      {
        id: "3",
        title: "Azul",
        description: "Tile-laying strategy game",
        category: "Strategy",
        playerCount: "2-4 Players",
        playTime: "30-45 min",
        difficulty: "Beginner",
        rating: 5,
        imageUrl: "https://pixabay.com/get/g1d647cc129bbc3ce8206e7fbb3efcdb9fbc4438f870997c41026e1d08491f7d2c2889c59eae42e56157d8669ea7e6e5c8f928141a0eaf7993c12dd2a6de6a1ec_1280.jpg",
        rules: "Azul is an abstract strategy board game designed by Michael Kiesling..."
      },
      {
        id: "4",
        title: "Splendor",
        description: "Engine building game with gems",
        category: "Strategy",
        playerCount: "2-4 Players",
        playTime: "30 min",
        difficulty: "Beginner",
        rating: 4,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=60",
        rules: "Splendor is a game of chip-collecting and card development..."
      },
      {
        id: "5",
        title: "Catan",
        description: "Settlement building and trading game",
        category: "Strategy",
        playerCount: "3-4 Players",
        playTime: "60-90 min",
        difficulty: "Intermediate",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        rules: "The Settlers of Catan is a multiplayer board game..."
      },
      {
        id: "6",
        title: "7 Wonders",
        description: "Civilization building through card drafting",
        category: "Strategy",
        playerCount: "2-7 Players",
        playTime: "30 min",
        difficulty: "Advanced",
        rating: 4,
        imageUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        rules: "7 Wonders is a board game created by Antoine Bauza..."
      },
      {
        id: "7",
        title: "Pandemic",
        description: "Cooperative disease-fighting game",
        category: "Cooperative",
        playerCount: "2-4 Players",
        playTime: "45 min",
        difficulty: "Intermediate",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1566694271453-390536dd1f0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        rules: "Pandemic is a cooperative board game designed by Matt Leacock..."
      }
    ];

    const sampleTutorials: Tutorial[] = [
      {
        id: "1",
        gameId: "1",
        title: "Setup and Game Board",
        description: "Organize components and understand board layout",
        stepNumber: 1,
        content: "Start by laying out the game board and organizing all components...",
        estimatedTime: 8,
        isQuickStart: false
      },
      {
        id: "2",
        gameId: "1", 
        title: "Understanding Bird Cards",
        description: "Learn to read bird card components and abilities",
        stepNumber: 2,
        content: "Each bird card contains important information...",
        estimatedTime: 5,
        isQuickStart: false
      },
      {
        id: "3",
        gameId: "1",
        title: "Habitat Actions Explained",
        description: "Master the four core habitat actions",
        stepNumber: 3,
        content: "The four habitat types each have unique actions...",
        estimatedTime: 12,
        isQuickStart: false
      },
      {
        id: "4",
        gameId: "2",
        title: "Ticket to Ride Quick Start",
        description: "Get playing in 5 minutes",
        stepNumber: 1,
        content: "Quick setup guide for Ticket to Ride...",
        estimatedTime: 5,
        isQuickStart: true
      },
      {
        id: "5",
        gameId: "3",
        title: "Azul Quick Start",
        description: "Start playing immediately",
        stepNumber: 1,
        content: "Quick setup guide for Azul...",
        estimatedTime: 3,
        isQuickStart: true
      },
      {
        id: "6",
        gameId: "4",
        title: "Splendor Quick Start",
        description: "Begin your gem empire",
        stepNumber: 1,
        content: "Quick setup guide for Splendor...",
        estimatedTime: 4,
        isQuickStart: true
      }
    ];

    const sampleLearningPaths: LearningPath[] = [
      {
        id: "1",
        title: "Strategy Games",
        description: "Master strategic thinking with classics like Chess, Catan, and Risk",
        category: "Strategy",
        gameIds: ["1", "2", "5", "6"],
        estimatedHours: 6,
        icon: "fas fa-route"
      },
      {
        id: "2",
        title: "Party Games",
        description: "Quick to learn games perfect for groups and gatherings",
        category: "Party",
        gameIds: ["3", "4"],
        estimatedHours: 3,
        icon: "fas fa-users"
      },
      {
        id: "3",
        title: "Engine Building",
        description: "Learn to build efficient systems in games like Wingspan and Splendor",
        category: "Engine Building",
        gameIds: ["1", "4"],
        estimatedHours: 4,
        icon: "fas fa-cog"
      }
    ];

    // Initialize sample user
    const sampleUser: User = {
      id: "user1",
      username: "alexjohnson",
      email: "alex@example.com",
      password: "password123",
      learningStreak: 12,
      totalGamesLearned: 23,
      totalTutorialsCompleted: 87
    };

    const sampleGoals: UserGoal[] = [
      {
        id: "goal1",
        userId: "user1",
        type: "weekly",
        target: 3,
        current: 2,
        description: "Complete 3 tutorials"
      },
      {
        id: "goal2", 
        userId: "user1",
        type: "weekly",
        target: 5,
        current: 4,
        description: "Study 5 days"
      },
      {
        id: "goal3",
        userId: "user1", 
        type: "weekly",
        target: 1,
        current: 1,
        description: "Learn 1 new game"
      }
    ];

    const sampleProgress: UserProgress[] = [
      {
        id: "progress1",
        userId: "user1",
        gameId: "1",
        tutorialId: "1",
        completed: true,
        currentStep: 1,
        timeSpent: 8
      },
      {
        id: "progress2",
        userId: "user1",
        gameId: "1", 
        tutorialId: "2",
        completed: true,
        currentStep: 1,
        timeSpent: 5
      },
      {
        id: "progress3",
        userId: "user1",
        gameId: "1",
        tutorialId: "3",
        completed: false,
        currentStep: 1,
        timeSpent: 3
      }
    ];

    // Populate maps
    this.users.set(sampleUser.id, sampleUser);
    sampleGames.forEach(game => this.games.set(game.id, game));
    sampleTutorials.forEach(tutorial => this.tutorials.set(tutorial.id, tutorial));
    sampleLearningPaths.forEach(path => this.learningPaths.set(path.id, path));
    sampleGoals.forEach(goal => this.userGoals.set(goal.id, goal));
    sampleProgress.forEach(progress => this.userProgress.set(progress.id, progress));
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      learningStreak: 0,
      totalGamesLearned: 0,
      totalTutorialsCompleted: 0
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Game operations
  async getAllGames(): Promise<Game[]> {
    return Array.from(this.games.values());
  }

  async getGame(id: string): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async searchGames(query: string): Promise<Game[]> {
    const lowQuery = query.toLowerCase();
    return Array.from(this.games.values()).filter(game => 
      game.title.toLowerCase().includes(lowQuery) ||
      game.description.toLowerCase().includes(lowQuery) ||
      game.category.toLowerCase().includes(lowQuery)
    );
  }

  async getGamesByCategory(category: string): Promise<Game[]> {
    return Array.from(this.games.values()).filter(game => 
      game.category.toLowerCase() === category.toLowerCase()
    );
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = randomUUID();
    const game: Game = { 
      ...insertGame, 
      id, 
      rating: 0,
      imageUrl: insertGame.imageUrl ?? null
    };
    this.games.set(id, game);
    return game;
  }

  // Tutorial operations
  async getTutorialsByGameId(gameId: string): Promise<Tutorial[]> {
    return Array.from(this.tutorials.values())
      .filter(tutorial => tutorial.gameId === gameId)
      .sort((a, b) => a.stepNumber - b.stepNumber);
  }

  async getTutorial(id: string): Promise<Tutorial | undefined> {
    return this.tutorials.get(id);
  }

  async getQuickStartTutorials(): Promise<Tutorial[]> {
    return Array.from(this.tutorials.values()).filter(tutorial => tutorial.isQuickStart);
  }

  async createTutorial(insertTutorial: InsertTutorial): Promise<Tutorial> {
    const id = randomUUID();
    const tutorial: Tutorial = { 
      ...insertTutorial, 
      id,
      isQuickStart: insertTutorial.isQuickStart ?? null
    };
    this.tutorials.set(id, tutorial);
    return tutorial;
  }

  // User progress operations
  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(progress => progress.userId === userId);
  }

  async getUserGameProgress(userId: string, gameId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values())
      .filter(progress => progress.userId === userId && progress.gameId === gameId);
  }

  async createUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const id = randomUUID();
    const progress: UserProgress = { 
      ...insertProgress, 
      id,
      tutorialId: insertProgress.tutorialId ?? null,
      completed: insertProgress.completed ?? null,
      currentStep: insertProgress.currentStep ?? null,
      timeSpent: insertProgress.timeSpent ?? null
    };
    this.userProgress.set(id, progress);
    return progress;
  }

  async updateUserProgress(id: string, updates: Partial<UserProgress>): Promise<UserProgress | undefined> {
    const progress = this.userProgress.get(id);
    if (!progress) return undefined;
    const updatedProgress = { ...progress, ...updates };
    this.userProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  // Learning paths
  async getAllLearningPaths(): Promise<LearningPath[]> {
    return Array.from(this.learningPaths.values());
  }

  async getLearningPath(id: string): Promise<LearningPath | undefined> {
    return this.learningPaths.get(id);
  }

  async createLearningPath(insertPath: InsertLearningPath): Promise<LearningPath> {
    const id = randomUUID();
    const path: LearningPath = { ...insertPath, id };
    this.learningPaths.set(id, path);
    return path;
  }

  // User goals
  async getUserGoals(userId: string): Promise<UserGoal[]> {
    return Array.from(this.userGoals.values()).filter(goal => goal.userId === userId);
  }

  async createUserGoal(insertGoal: InsertUserGoal): Promise<UserGoal> {
    const id = randomUUID();
    const goal: UserGoal = { 
      ...insertGoal, 
      id,
      current: insertGoal.current ?? null
    };
    this.userGoals.set(id, goal);
    return goal;
  }

  async updateUserGoal(id: string, updates: Partial<UserGoal>): Promise<UserGoal | undefined> {
    const goal = this.userGoals.get(id);
    if (!goal) return undefined;
    const updatedGoal = { ...goal, ...updates };
    this.userGoals.set(id, updatedGoal);
    return updatedGoal;
  }
}

// Create database storage instance and initialize with sample data
const dbStorage = new DBStorage();
dbStorage.initializeData().catch(console.error);

export const storage = dbStorage;
