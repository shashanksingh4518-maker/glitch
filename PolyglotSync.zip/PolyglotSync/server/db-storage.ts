import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, and, ilike, inArray } from "drizzle-orm";
import { 
  users, games, tutorials, userProgress, learningPaths, userGoals,
  type User, type InsertUser, type Game, type InsertGame, 
  type Tutorial, type InsertTutorial, type UserProgress, type InsertUserProgress,
  type LearningPath, type InsertLearningPath, type UserGoal, type InsertUserGoal 
} from "@shared/schema";
import type { IStorage } from "./storage";

const sql = neon(process.env.DATABASE_URL!);
const db = drizzle(sql);

export class DBStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return result[0];
  }

  // Game operations
  async getAllGames(): Promise<Game[]> {
    return await db.select().from(games);
  }

  async getGame(id: string): Promise<Game | undefined> {
    const result = await db.select().from(games).where(eq(games.id, id));
    return result[0];
  }

  async searchGames(query: string): Promise<Game[]> {
    return await db.select().from(games).where(
      ilike(games.title, `%${query}%`)
    );
  }

  async getGamesByCategory(category: string): Promise<Game[]> {
    return await db.select().from(games).where(eq(games.category, category));
  }

  async createGame(game: InsertGame): Promise<Game> {
    const result = await db.insert(games).values(game).returning();
    return result[0];
  }

  // Tutorial operations
  async getTutorialsByGameId(gameId: string): Promise<Tutorial[]> {
    return await db.select().from(tutorials)
      .where(eq(tutorials.gameId, gameId))
      .orderBy(tutorials.stepNumber);
  }

  async getTutorial(id: string): Promise<Tutorial | undefined> {
    const result = await db.select().from(tutorials).where(eq(tutorials.id, id));
    return result[0];
  }

  async getQuickStartTutorials(): Promise<Tutorial[]> {
    return await db.select().from(tutorials).where(eq(tutorials.isQuickStart, true));
  }

  async createTutorial(tutorial: InsertTutorial): Promise<Tutorial> {
    const result = await db.insert(tutorials).values(tutorial).returning();
    return result[0];
  }

  // User progress operations
  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async getUserGameProgress(userId: string, gameId: string): Promise<UserProgress[]> {
    return await db.select().from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.gameId, gameId)));
  }

  async createUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const result = await db.insert(userProgress).values(progress).returning();
    return result[0];
  }

  async updateUserProgress(id: string, updates: Partial<UserProgress>): Promise<UserProgress | undefined> {
    const result = await db.update(userProgress).set(updates).where(eq(userProgress.id, id)).returning();
    return result[0];
  }

  // Learning paths
  async getAllLearningPaths(): Promise<LearningPath[]> {
    return await db.select().from(learningPaths);
  }

  async getLearningPath(id: string): Promise<LearningPath | undefined> {
    const result = await db.select().from(learningPaths).where(eq(learningPaths.id, id));
    return result[0];
  }

  async createLearningPath(path: InsertLearningPath): Promise<LearningPath> {
    const result = await db.insert(learningPaths).values(path).returning();
    return result[0];
  }

  // User goals
  async getUserGoals(userId: string): Promise<UserGoal[]> {
    return await db.select().from(userGoals).where(eq(userGoals.userId, userId));
  }

  async createUserGoal(goal: InsertUserGoal): Promise<UserGoal> {
    const result = await db.insert(userGoals).values(goal).returning();
    return result[0];
  }

  async updateUserGoal(id: string, updates: Partial<UserGoal>): Promise<UserGoal | undefined> {
    const result = await db.update(userGoals).set(updates).where(eq(userGoals.id, id)).returning();
    return result[0];
  }

  // Initialize database with sample data
  async initializeData(): Promise<void> {
    // Check if data already exists
    const existingGames = await this.getAllGames();
    if (existingGames.length > 0) {
      return; // Data already exists
    }

    // Insert sample games with predictable IDs
    const sampleGames = [
      {
        id: "1", // Use predictable ID for compatibility with frontend
        title: "Wingspan",
        description: "Engine-building strategy game about birds",
        category: "Strategy",
        playerCount: "1-5 Players",
        playTime: "40-70 min",
        difficulty: "Intermediate",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1632501641765-e568d28b0015?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rules: "Wingspan is a competitive, medium-weight, card-driven, engine-building board game..."
      },
      {
        id: "2",
        title: "Ticket to Ride",
        description: "Railway-themed adventure board game",
        category: "Strategy",
        playerCount: "2-5 Players",
        playTime: "30-60 min",
        difficulty: "Beginner",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        rules: "Ticket to Ride is a railway-themed German-style board game..."
      },
      {
        id: "3",
        title: "Azul",
        description: "Tile-laying strategy game",
        category: "Strategy",
        playerCount: "2-4 Players",
        playTime: "30-45 min",
        difficulty: "Beginner",
        rating: 5,
        imageUrl: "https://pixabay.com/get/g1d647cc129bbc3ce8206e7fbb3efcdb9fbc4438f870997c41026e1d08491f7d2c2889c59eae42e56157d8669ea7e6e5c8f928141a0eaf7993c12dd2a6de6a1ec_1280.jpg",
        rules: "Azul is an abstract strategy board game designed by Michael Kiesling..."
      },
      {
        id: "4",
        title: "Splendor",
        description: "Engine building game with gems",
        category: "Strategy",
        playerCount: "2-4 Players",
        playTime: "30 min",
        difficulty: "Beginner",
        rating: 4,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=60",
        rules: "Splendor is a game of chip-collecting and card development..."
      },
      {
        id: "5",
        title: "Catan",
        description: "Settlement building and trading game",
        category: "Strategy",
        playerCount: "3-4 Players",
        playTime: "60-90 min",
        difficulty: "Intermediate",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        rules: "The Settlers of Catan is a multiplayer board game..."
      },
      {
        id: "6",
        title: "7 Wonders",
        description: "Civilization building through card drafting",
        category: "Strategy",
        playerCount: "2-7 Players",
        playTime: "30 min",
        difficulty: "Advanced",
        rating: 4,
        imageUrl: "https://images.unsplash.com/photo-1511512578047-dfb367046420?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        rules: "7 Wonders is a board game created by Antoine Bauza..."
      },
      {
        id: "7",
        title: "Pandemic",
        description: "Cooperative disease-fighting game",
        category: "Cooperative",
        playerCount: "2-4 Players",
        playTime: "45 min",
        difficulty: "Intermediate",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1566694271453-390536dd1f0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        rules: "Pandemic is a cooperative board game designed by Matt Leacock..."
      }
    ];

    const insertedGames = await db.insert(games).values(sampleGames).returning();

    // Insert sample tutorials
    const sampleTutorials = [
      {
        gameId: insertedGames[0].id, // Wingspan
        title: "Setup and Game Board",
        description: "Organize components and understand board layout",
        stepNumber: 1,
        content: "Start by laying out the game board and organizing all components...",
        estimatedTime: 8,
        isQuickStart: false
      },
      {
        gameId: insertedGames[0].id, // Wingspan
        title: "Understanding Bird Cards",
        description: "Learn to read bird card components and abilities",
        stepNumber: 2,
        content: "Each bird card contains important information...",
        estimatedTime: 5,
        isQuickStart: false
      },
      {
        gameId: insertedGames[0].id, // Wingspan
        title: "Habitat Actions Explained",
        description: "Master the four core habitat actions",
        stepNumber: 3,
        content: "The four habitat types each have unique actions...",
        estimatedTime: 12,
        isQuickStart: false
      },
      {
        gameId: insertedGames[1].id, // Ticket to Ride
        title: "Ticket to Ride Quick Start",
        description: "Get playing in 5 minutes",
        stepNumber: 1,
        content: "Quick setup guide for Ticket to Ride...",
        estimatedTime: 5,
        isQuickStart: true
      },
      {
        gameId: insertedGames[2].id, // Azul
        title: "Azul Quick Start",
        description: "Start playing immediately",
        stepNumber: 1,
        content: "Quick setup guide for Azul...",
        estimatedTime: 3,
        isQuickStart: true
      },
      {
        gameId: insertedGames[3].id, // Splendor
        title: "Splendor Quick Start",
        description: "Begin your gem empire",
        stepNumber: 1,
        content: "Quick setup guide for Splendor...",
        estimatedTime: 4,
        isQuickStart: true
      }
    ];

    const insertedTutorials = await db.insert(tutorials).values(sampleTutorials).returning();

    // Insert sample learning paths
    const sampleLearningPaths = [
      {
        title: "Strategy Games",
        description: "Master strategic thinking with classics like Chess, Catan, and Risk",
        category: "Strategy",
        gameIds: [insertedGames[0].id, insertedGames[1].id, insertedGames[4].id, insertedGames[5].id],
        estimatedHours: 6,
        icon: "fas fa-route"
      },
      {
        title: "Party Games",
        description: "Quick to learn games perfect for groups and gatherings",
        category: "Party",
        gameIds: [insertedGames[2].id, insertedGames[3].id],
        estimatedHours: 3,
        icon: "fas fa-users"
      },
      {
        title: "Engine Building",
        description: "Learn to build efficient systems in games like Wingspan and Splendor",
        category: "Engine Building",
        gameIds: [insertedGames[0].id, insertedGames[3].id],
        estimatedHours: 4,
        icon: "fas fa-cog"
      }
    ];

    await db.insert(learningPaths).values(sampleLearningPaths);

    // Insert sample user with predictable ID
    const sampleUser = {
      id: "user1", // Use predictable ID for compatibility with frontend
      username: "alexjohnson",
      email: "alex@example.com",
      password: "password123",
      learningStreak: 12,
      totalGamesLearned: 23,
      totalTutorialsCompleted: 87
    };

    const insertedUsers = await db.insert(users).values(sampleUser).returning();

    // Insert sample goals
    const sampleGoals = [
      {
        userId: insertedUsers[0].id,
        type: "weekly",
        target: 3,
        current: 2,
        description: "Complete 3 tutorials"
      },
      {
        userId: insertedUsers[0].id,
        type: "weekly",
        target: 5,
        current: 4,
        description: "Study 5 days"
      },
      {
        userId: insertedUsers[0].id,
        type: "weekly",
        target: 1,
        current: 1,
        description: "Learn 1 new game"
      }
    ];

    await db.insert(userGoals).values(sampleGoals);

    // Insert sample progress
    const sampleProgress = [
      {
        userId: insertedUsers[0].id,
        gameId: insertedGames[0].id,
        tutorialId: insertedTutorials[0].id,
        completed: true,
        currentStep: 1,
        timeSpent: 8
      },
      {
        userId: insertedUsers[0].id,
        gameId: insertedGames[0].id,
        tutorialId: insertedTutorials[1].id,
        completed: true,
        currentStep: 1,
        timeSpent: 5
      },
      {
        userId: insertedUsers[0].id,
        gameId: insertedGames[0].id,
        tutorialId: insertedTutorials[2].id,
        completed: false,
        currentStep: 1,
        timeSpent: 3
      }
    ];

    await db.insert(userProgress).values(sampleProgress);
  }
}