import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import GameCard from "@/components/game-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter } from "lucide-react";
import type { Game } from "@shared/schema";

export default function BrowseGames() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedDifficulty, setSelectedDifficulty] = useState<string | null>(null);

  const { data: allGames = [], isLoading } = useQuery<Game[]>({
    queryKey: ["/api/games"]
  });

  const { data: searchResults = [] } = useQuery<Game[]>({
    queryKey: ["/api/games/search", searchQuery],
    enabled: searchQuery.length > 0
  });

  const displayGames = searchQuery.length > 0 ? searchResults : allGames;

  const filteredGames = displayGames.filter(game => {
    if (selectedCategory && game.category !== selectedCategory) return false;
    if (selectedDifficulty && game.difficulty !== selectedDifficulty) return false;
    return true;
  });

  const categories = Array.from(new Set(allGames.map(game => game.category)));
  const difficulties = Array.from(new Set(allGames.map(game => game.difficulty)));

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 flex flex-col">
        <Header />
        
        <div className="flex-1 p-6 overflow-y-auto">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">Browse Games</h1>
            <p className="text-muted-foreground" data-testid="text-page-description">
              Discover and learn new board games from our comprehensive collection
            </p>
          </div>

          {/* Search and Filters */}
          <Card className="mb-8" data-testid="card-search-filters">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row gap-4">
                {/* Search */}
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
                  <Input
                    placeholder="Search games, rules, or categories..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                    data-testid="input-search"
                  />
                </div>

                {/* Category Filter */}
                <div className="flex items-center space-x-2">
                  <Filter size={16} className="text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Category:</span>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant={selectedCategory === null ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedCategory(null)}
                      data-testid="button-category-all"
                    >
                      All
                    </Button>
                    {categories.map(category => (
                      <Button
                        key={category}
                        variant={selectedCategory === category ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCategory(category)}
                        data-testid={`button-category-${category.toLowerCase()}`}
                      >
                        {category}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Difficulty Filter */}
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">Difficulty:</span>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant={selectedDifficulty === null ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedDifficulty(null)}
                      data-testid="button-difficulty-all"
                    >
                      All
                    </Button>
                    {difficulties.map(difficulty => (
                      <Button
                        key={difficulty}
                        variant={selectedDifficulty === difficulty ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedDifficulty(difficulty)}
                        data-testid={`button-difficulty-${difficulty.toLowerCase()}`}
                      >
                        {difficulty}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Applied Filters */}
          {(selectedCategory || selectedDifficulty) && (
            <div className="mb-6">
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-sm text-muted-foreground">Active filters:</span>
                {selectedCategory && (
                  <Badge variant="secondary" className="flex items-center space-x-1" data-testid="badge-active-category">
                    <span>{selectedCategory}</span>
                    <button 
                      onClick={() => setSelectedCategory(null)}
                      className="ml-1 hover:text-destructive"
                      data-testid="button-remove-category"
                    >
                      ×
                    </button>
                  </Badge>
                )}
                {selectedDifficulty && (
                  <Badge variant="secondary" className="flex items-center space-x-1" data-testid="badge-active-difficulty">
                    <span>{selectedDifficulty}</span>
                    <button 
                      onClick={() => setSelectedDifficulty(null)}
                      className="ml-1 hover:text-destructive"
                      data-testid="button-remove-difficulty"
                    >
                      ×
                    </button>
                  </Badge>
                )}
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => {
                    setSelectedCategory(null);
                    setSelectedDifficulty(null);
                  }}
                  data-testid="button-clear-filters"
                >
                  Clear all
                </Button>
              </div>
            </div>
          )}

          {/* Results Summary */}
          <div className="mb-6">
            <p className="text-muted-foreground" data-testid="text-results-summary">
              {searchQuery ? `Search results for "${searchQuery}": ` : ""}
              {filteredGames.length} game{filteredGames.length !== 1 ? 's' : ''} found
            </p>
          </div>

          {/* Games Grid */}
          {filteredGames.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" data-testid="grid-games">
              {filteredGames.map((game) => (
                <GameCard key={game.id} game={game} data-testid={`game-card-${game.id}`} />
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center" data-testid="card-no-results">
              <CardContent>
                <h3 className="text-lg font-semibold mb-2">No games found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchQuery 
                    ? `No games match your search for "${searchQuery}"`
                    : "No games match your current filters"
                  }
                </p>
                <Button 
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory(null);
                    setSelectedDifficulty(null);
                  }}
                  data-testid="button-reset-search"
                >
                  Reset Search
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
