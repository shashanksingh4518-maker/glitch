import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import GameCard from "@/components/game-card";
import ProgressCard from "@/components/progress-card";
import TutorialStep from "@/components/tutorial-step";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Trophy, Flame, GraduationCap, Clock, Route, Users, Cog, PlayCircle, ArrowRight } from "lucide-react";
import type { Game, User, UserGoal, LearningPath, Tutorial, UserProgress } from "@shared/schema";

export default function Dashboard() {
  const { data: games = [] } = useQuery<Game[]>({
    queryKey: ["/api/games"]
  });

  const { data: user } = useQuery<User>({
    queryKey: ["/api/users/user1"]
  });

  const { data: goals = [] } = useQuery<UserGoal[]>({
    queryKey: ["/api/users/user1/goals"]
  });

  const { data: learningPaths = [] } = useQuery<LearningPath[]>({
    queryKey: ["/api/learning-paths"]
  });

  const { data: quickStartTutorials = [] } = useQuery<Tutorial[]>({
    queryKey: ["/api/tutorials/quick-start"]
  });

  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/users/user1/progress"]
  });

  const { data: wingspanTutorials = [] } = useQuery<Tutorial[]>({
    queryKey: ["/api/games/1/tutorials"]
  });

  const currentGame = games.find(g => g.id === "1"); // Wingspan
  const wingspanProgress = userProgress.filter(p => p.gameId === "1");
  const completedSteps = wingspanProgress.filter(p => p.completed).length;
  const totalSteps = wingspanTutorials.length;
  const progressPercentage = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

  const popularGames = games.slice(0, 4);

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 flex flex-col">
        <Header />
        
        <div className="flex-1 p-6 overflow-y-auto">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card data-testid="card-games-learned">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Games Learned</p>
                    <p className="text-2xl font-bold" data-testid="text-games-learned">
                      {user?.totalGamesLearned || 0}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Trophy className="text-primary" size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card data-testid="card-study-streak">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Study Streak</p>
                    <p className="text-2xl font-bold" data-testid="text-study-streak">
                      {user?.learningStreak || 0} days
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <Flame className="text-accent" size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card data-testid="card-tutorials-completed">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Tutorials Completed</p>
                    <p className="text-2xl font-bold" data-testid="text-tutorials-completed">
                      {user?.totalTutorialsCompleted || 0}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <GraduationCap className="text-green-600" size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card data-testid="card-time-saved">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Time Saved</p>
                    <p className="text-2xl font-bold" data-testid="text-time-saved">4.2 hrs</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Clock className="text-blue-600" size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold mb-6">Continue Learning</h2>
              
              {/* Current Game Progress */}
              {currentGame && (
                <Card className="mb-8" data-testid="card-current-learning">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <img 
                        src={currentGame.imageUrl || ""} 
                        alt={currentGame.title}
                        className="w-24 h-24 rounded-lg object-cover"
                        data-testid="img-current-game"
                      />
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold" data-testid="text-current-game-title">
                          {currentGame.title}
                        </h3>
                        <p className="text-muted-foreground mb-2" data-testid="text-current-game-description">
                          {currentGame.description}
                        </p>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span data-testid="text-player-count">{currentGame.playerCount}</span>
                          <span data-testid="text-play-time">{currentGame.playTime}</span>
                          <span data-testid="text-difficulty">{currentGame.difficulty}</span>
                        </div>
                      </div>
                      <Button data-testid="button-continue-tutorial">
                        Continue Tutorial
                      </Button>
                    </div>
                    
                    <div className="mt-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-muted-foreground">
                          Progress: Step {completedSteps + 1} of {totalSteps}
                        </span>
                        <span className="text-sm font-medium" data-testid="text-progress-percentage">
                          {progressPercentage}% Complete
                        </span>
                      </div>
                      <Progress value={progressPercentage} className="h-2" data-testid="progress-current-game" />
                    </div>
                  </CardContent>
                  
                  <div className="border-t border-border p-4 bg-muted/50">
                    <p className="text-sm text-muted-foreground" data-testid="text-next-lesson">
                      Next: Learn about the four habitat types and their unique actions
                    </p>
                  </div>
                </Card>
              )}

              {/* Recent Tutorial Steps */}
              <h3 className="text-xl font-semibold mt-8 mb-4">Recent Tutorial Steps</h3>
              <div className="space-y-3">
                {wingspanTutorials.slice(0, 3).map((tutorial, index) => {
                  const progress = wingspanProgress.find(p => p.tutorialId === tutorial.id);
                  const isCompleted = progress?.completed || false;
                  const isCurrent = index === 2; // Third tutorial is current
                  
                  return (
                    <TutorialStep
                      key={tutorial.id}
                      tutorial={tutorial}
                      isCompleted={isCompleted}
                      isCurrent={isCurrent}
                      data-testid={`tutorial-step-${tutorial.id}`}
                    />
                  );
                })}
              </div>
            </div>
            
            {/* Sidebar Content */}
            <div className="space-y-6">
              {/* Weekly Goals */}
              <Card data-testid="card-weekly-goals">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Weekly Goals</h3>
                  <div className="space-y-4">
                    {goals.map((goal) => (
                      <div key={goal.id} data-testid={`goal-${goal.id}`}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-muted-foreground" data-testid={`text-goal-description-${goal.id}`}>
                            {goal.description}
                          </span>
                          <span className="text-sm font-medium" data-testid={`text-goal-progress-${goal.id}`}>
                            {goal.current ?? 0}/{goal.target}
                          </span>
                        </div>
                        <Progress 
                          value={((goal.current ?? 0) / goal.target) * 100} 
                          className="h-2"
                          data-testid={`progress-goal-${goal.id}`}
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Start Guides */}
              <Card data-testid="card-quick-start">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Quick Start Guides</h3>
                  <div className="space-y-3">
                    {quickStartTutorials.map((tutorial) => {
                      const game = games.find(g => g.id === tutorial.gameId);
                      return (
                        <Button
                          key={tutorial.id}
                          variant="ghost"
                          className="w-full justify-start p-3 h-auto"
                          data-testid={`button-quick-start-${tutorial.id}`}
                        >
                          <div className="flex items-center space-x-3">
                            <PlayCircle className="text-primary" size={20} />
                            <div className="text-left">
                              <p className="font-medium" data-testid={`text-quick-start-title-${tutorial.id}`}>
                                {game?.title}
                              </p>
                              <p className="text-sm text-muted-foreground" data-testid={`text-quick-start-time-${tutorial.id}`}>
                                {tutorial.estimatedTime} min setup
                              </p>
                            </div>
                          </div>
                        </Button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Recommended Games */}
              <Card data-testid="card-recommended">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Recommended for You</h3>
                  <div className="space-y-4">
                    {games.slice(2, 4).map((game) => (
                      <div key={game.id} className="flex items-start space-x-3" data-testid={`recommended-game-${game.id}`}>
                        <img 
                          src={game.imageUrl || ""} 
                          alt={game.title}
                          className="w-12 h-12 rounded object-cover"
                          data-testid={`img-recommended-${game.id}`}
                        />
                        <div className="flex-1">
                          <h4 className="font-medium" data-testid={`text-recommended-title-${game.id}`}>
                            {game.title}
                          </h4>
                          <p className="text-xs text-muted-foreground" data-testid={`text-recommended-category-${game.id}`}>
                            {game.category}
                          </p>
                          <div className="flex items-center mt-1">
                            <div className="flex text-yellow-400 text-xs">
                              {Array.from({ length: game.rating ?? 0 }).map((_, i) => (
                                <span key={i}>★</span>
                              ))}
                            </div>
                            <span className="text-xs text-muted-foreground ml-1" data-testid={`text-recommended-rating-${game.id}`}>
                              {game.rating}.0
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Popular Games */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Popular Games</h2>
              <Button variant="ghost" className="text-primary hover:text-primary/80" data-testid="button-view-all-games">
                View All <ArrowRight className="ml-1" size={16} />
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {popularGames.map((game) => (
                <GameCard key={game.id} game={game} data-testid={`game-card-${game.id}`} />
              ))}
            </div>
          </div>

          {/* Learning Paths */}
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 rounded-xl p-8 border border-border" data-testid="section-learning-paths">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold">Learning Paths</h2>
                <p className="text-muted-foreground">Structured courses to master different game types</p>
              </div>
              <Button data-testid="button-view-all-paths">
                View All Paths
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {learningPaths.map((path, index) => {
                const IconComponent = path.icon === "fas fa-route" ? Route : 
                                    path.icon === "fas fa-users" ? Users : Cog;
                const progressPercentage = index === 0 ? 25 : index === 1 ? 0 : 50;
                
                return (
                  <Card key={path.id} data-testid={`learning-path-${path.id}`}>
                    <CardContent className="p-6">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                        <IconComponent className="text-primary" size={20} />
                      </div>
                      <h3 className="text-lg font-semibold mb-2" data-testid={`text-path-title-${path.id}`}>
                        {path.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4" data-testid={`text-path-description-${path.id}`}>
                        {path.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground" data-testid={`text-path-details-${path.id}`}>
                          {path.gameIds.length} games • {path.estimatedHours} hours
                        </span>
                        <div className="flex items-center">
                          <Progress value={progressPercentage} className="w-16 h-1 mr-2" />
                          <span className="text-xs" data-testid={`text-path-progress-${path.id}`}>
                            {progressPercentage}%
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
