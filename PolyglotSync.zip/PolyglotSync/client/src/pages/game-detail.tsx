import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import TutorialStep from "@/components/tutorial-step";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, Clock, Star, PlayCircle } from "lucide-react";
import type { Game, Tutorial, UserProgress } from "@shared/schema";

export default function GameDetail() {
  const [match, params] = useRoute("/games/:id");
  const gameId = params?.id;

  const { data: game, isLoading: gameLoading } = useQuery<Game>({
    queryKey: ["/api/games", gameId],
    enabled: !!gameId
  });

  const { data: tutorials = [] } = useQuery<Tutorial[]>({
    queryKey: ["/api/games", gameId, "tutorials"],
    enabled: !!gameId
  });

  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/users/user1/games", gameId, "progress"],
    enabled: !!gameId
  });

  if (!match || !gameId) {
    return <div>Game not found</div>;
  }

  if (gameLoading) {
    return <div>Loading...</div>;
  }

  if (!game) {
    return <div>Game not found</div>;
  }

  const completedTutorials = userProgress.filter(p => p.completed).length;
  const totalTutorials = tutorials.length;
  const progressPercentage = totalTutorials > 0 ? Math.round((completedTutorials / totalTutorials) * 100) : 0;

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "beginner":
        return "bg-green-100 text-green-800";
      case "intermediate":
        return "bg-yellow-100 text-yellow-800";
      case "advanced":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 flex flex-col">
        <Header />
        
        <div className="flex-1 p-6 overflow-y-auto">
          {/* Game Header */}
          <div className="mb-8">
            <div className="flex items-start space-x-6">
              <img 
                src={game.imageUrl || ""} 
                alt={game.title}
                className="w-32 h-32 rounded-lg object-cover"
                data-testid="img-game-cover"
              />
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2" data-testid="text-game-title">
                  {game.title}
                </h1>
                <p className="text-muted-foreground mb-4" data-testid="text-game-description">
                  {game.description}
                </p>
                
                <div className="flex items-center space-x-6 mb-4">
                  <div className="flex items-center space-x-2">
                    <Users size={16} className="text-muted-foreground" />
                    <span className="text-sm" data-testid="text-player-count">{game.playerCount}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock size={16} className="text-muted-foreground" />
                    <span className="text-sm" data-testid="text-play-time">{game.playTime}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Star size={16} className="text-yellow-500" />
                    <span className="text-sm" data-testid="text-rating">{game.rating}.0</span>
                  </div>
                  <Badge className={getDifficultyColor(game.difficulty)} data-testid="badge-difficulty">
                    {game.difficulty}
                  </Badge>
                </div>

                <div className="flex items-center space-x-4">
                  <Button size="lg" data-testid="button-start-learning">
                    <PlayCircle className="mr-2" size={20} />
                    Start Learning
                  </Button>
                  <Button variant="outline" size="lg" data-testid="button-quick-start">
                    Quick Start Guide
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Progress Overview */}
          <Card className="mb-8" data-testid="card-progress-overview">
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-muted-foreground">
                  {completedTutorials} of {totalTutorials} tutorials completed
                </span>
                <span className="text-sm font-medium" data-testid="text-progress-percentage">
                  {progressPercentage}% Complete
                </span>
              </div>
              <Progress value={progressPercentage} className="h-3" data-testid="progress-game-learning" />
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Tutorials List */}
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold mb-6">Learning Path</h2>
              
              <div className="space-y-4">
                {tutorials.map((tutorial) => {
                  const progress = userProgress.find(p => p.tutorialId === tutorial.id);
                  const isCompleted = progress?.completed || false;
                  const isCurrent = !isCompleted && tutorial.stepNumber === (completedTutorials + 1);
                  
                  return (
                    <TutorialStep
                      key={tutorial.id}
                      tutorial={tutorial}
                      isCompleted={isCompleted}
                      isCurrent={isCurrent}
                      showStepNumber={true}
                      data-testid={`tutorial-step-${tutorial.id}`}
                    />
                  );
                })}
              </div>
            </div>

            {/* Game Rules Summary */}
            <div>
              <Card data-testid="card-game-rules">
                <CardHeader>
                  <CardTitle>Game Rules Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4" data-testid="text-rules-summary">
                    {game.rules}
                  </p>
                  <Button variant="outline" className="w-full" data-testid="button-full-rules">
                    View Full Rulebook
                  </Button>
                </CardContent>
              </Card>

              <Card className="mt-6" data-testid="card-game-stats">
                <CardHeader>
                  <CardTitle>Game Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Category</span>
                    <span className="text-sm font-medium" data-testid="text-category">{game.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Players</span>
                    <span className="text-sm font-medium" data-testid="text-players">{game.playerCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Play Time</span>
                    <span className="text-sm font-medium" data-testid="text-time">{game.playTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Difficulty</span>
                    <Badge className={getDifficultyColor(game.difficulty)} data-testid="badge-difficulty-sidebar">
                      {game.difficulty}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Rating</span>
                    <div className="flex items-center space-x-1">
                      <div className="flex text-yellow-400 text-sm">
                        {Array.from({ length: game.rating ?? 0 }).map((_, i) => (
                          <Star key={i} size={12} fill="currentColor" />
                        ))}
                      </div>
                      <span className="text-sm font-medium" data-testid="text-rating-sidebar">{game.rating}.0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
