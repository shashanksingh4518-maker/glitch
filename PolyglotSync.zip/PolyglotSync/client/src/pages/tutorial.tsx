import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, ArrowLeft, ArrowRight } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Tutorial, Game, UserProgress } from "@shared/schema";

export default function TutorialPage() {
  const [match, params] = useRoute("/tutorials/:id");
  const tutorialId = params?.id;
  const [isCompleting, setIsCompleting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tutorial, isLoading: tutorialLoading } = useQuery<Tutorial>({
    queryKey: ["/api/tutorials", tutorialId],
    enabled: !!tutorialId
  });

  const { data: game } = useQuery<Game>({
    queryKey: ["/api/games", tutorial?.gameId],
    enabled: !!tutorial?.gameId
  });

  const { data: allTutorials = [] } = useQuery<Tutorial[]>({
    queryKey: ["/api/games", tutorial?.gameId, "tutorials"],
    enabled: !!tutorial?.gameId
  });

  const { data: userProgress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/users/user1/games", tutorial?.gameId, "progress"],
    enabled: !!tutorial?.gameId
  });

  const completeTutorialMutation = useMutation({
    mutationFn: async () => {
      if (!tutorial) return;
      
      const existingProgress = userProgress.find(p => p.tutorialId === tutorial.id);
      
      if (existingProgress) {
        return apiRequest("PATCH", `/api/progress/${existingProgress.id}`, {
          completed: true,
          timeSpent: (existingProgress.timeSpent || 0) + tutorial.estimatedTime
        });
      } else {
        return apiRequest("POST", `/api/users/user1/progress`, {
          gameId: tutorial.gameId,
          tutorialId: tutorial.id,
          completed: true,
          currentStep: 1,
          timeSpent: tutorial.estimatedTime
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users/user1/games", tutorial?.gameId, "progress"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users/user1/progress"] });
      toast({
        title: "Tutorial Completed!",
        description: "Great job! You've completed this tutorial step.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to mark tutorial as complete. Please try again.",
        variant: "destructive",
      });
    }
  });

  if (!match || !tutorialId) {
    return <div>Tutorial not found</div>;
  }

  if (tutorialLoading) {
    return <div>Loading...</div>;
  }

  if (!tutorial) {
    return <div>Tutorial not found</div>;
  }

  const currentProgress = userProgress.find(p => p.tutorialId === tutorial.id);
  const isCompleted = currentProgress?.completed || false;
  
  const completedCount = userProgress.filter(p => p.completed).length;
  const totalCount = allTutorials.length;
  const overallProgress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const currentIndex = allTutorials.findIndex(t => t.id === tutorial.id);
  const previousTutorial = currentIndex > 0 ? allTutorials[currentIndex - 1] : null;
  const nextTutorial = currentIndex < allTutorials.length - 1 ? allTutorials[currentIndex + 1] : null;

  const handleComplete = async () => {
    setIsCompleting(true);
    try {
      await completeTutorialMutation.mutateAsync();
    } finally {
      setIsCompleting(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 flex flex-col">
        <Header />
        
        <div className="flex-1 p-6 overflow-y-auto">
          {/* Tutorial Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm" data-testid="button-back-to-game">
                  <ArrowLeft size={16} className="mr-2" />
                  Back to {game?.title}
                </Button>
                <Badge variant="outline" data-testid="badge-step-number">
                  Step {tutorial.stepNumber}
                </Badge>
                {isCompleted && (
                  <Badge className="bg-green-100 text-green-800" data-testid="badge-completed">
                    <CheckCircle size={12} className="mr-1" />
                    Completed
                  </Badge>
                )}
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Clock size={16} />
                <span data-testid="text-estimated-time">{tutorial.estimatedTime} min</span>
              </div>
            </div>
            
            <h1 className="text-3xl font-bold mb-2" data-testid="text-tutorial-title">
              {tutorial.title}
            </h1>
            <p className="text-muted-foreground" data-testid="text-tutorial-description">
              {tutorial.description}
            </p>
          </div>

          {/* Progress Overview */}
          <Card className="mb-8" data-testid="card-progress-overview">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-muted-foreground">
                  Overall Progress: {completedCount} of {totalCount} tutorials
                </span>
                <span className="text-sm font-medium" data-testid="text-overall-progress">
                  {overallProgress}% Complete
                </span>
              </div>
              <Progress value={overallProgress} className="h-2" data-testid="progress-overall" />
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Tutorial Content */}
            <div className="lg:col-span-2">
              <Card data-testid="card-tutorial-content">
                <CardHeader>
                  <CardTitle>Tutorial Content</CardTitle>
                </CardHeader>
                <CardContent className="prose max-w-none">
                  <div className="text-sm leading-relaxed" data-testid="text-tutorial-content">
                    {tutorial.content}
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="flex items-center justify-between mt-8">
                <div>
                  {previousTutorial && (
                    <Button variant="outline" data-testid="button-previous-tutorial">
                      <ArrowLeft size={16} className="mr-2" />
                      Previous: {previousTutorial.title}
                    </Button>
                  )}
                </div>
                
                <div className="flex items-center space-x-4">
                  {!isCompleted && (
                    <Button 
                      onClick={handleComplete}
                      disabled={isCompleting || completeTutorialMutation.isPending}
                      data-testid="button-complete-tutorial"
                    >
                      <CheckCircle size={16} className="mr-2" />
                      {isCompleting ? "Marking Complete..." : "Mark as Complete"}
                    </Button>
                  )}
                  
                  {nextTutorial && (
                    <Button data-testid="button-next-tutorial">
                      Next: {nextTutorial.title}
                      <ArrowRight size={16} className="ml-2" />
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Tutorial Info */}
              <Card data-testid="card-tutorial-info">
                <CardHeader>
                  <CardTitle>Tutorial Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Game</span>
                    <span className="text-sm font-medium" data-testid="text-game-name">{game?.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Step</span>
                    <span className="text-sm font-medium" data-testid="text-step-info">
                      {tutorial.stepNumber} of {totalCount}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Estimated Time</span>
                    <span className="text-sm font-medium" data-testid="text-time-info">
                      {tutorial.estimatedTime} minutes
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Status</span>
                    <Badge 
                      className={isCompleted ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}
                      data-testid="badge-status"
                    >
                      {isCompleted ? "Completed" : "In Progress"}
                    </Badge>
                  </div>
                  {currentProgress?.timeSpent && (
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Time Spent</span>
                      <span className="text-sm font-medium" data-testid="text-time-spent">
                        {currentProgress.timeSpent} min
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* All Steps */}
              <Card data-testid="card-all-steps">
                <CardHeader>
                  <CardTitle>All Tutorial Steps</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {allTutorials.map((step) => {
                      const stepProgress = userProgress.find(p => p.tutorialId === step.id);
                      const stepCompleted = stepProgress?.completed || false;
                      const isCurrentStep = step.id === tutorial.id;
                      
                      return (
                        <div 
                          key={step.id}
                          className={`flex items-center space-x-3 p-2 rounded-lg ${
                            isCurrentStep ? "bg-primary/10 border border-primary/20" : ""
                          }`}
                          data-testid={`step-item-${step.id}`}
                        >
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                            stepCompleted 
                              ? "bg-green-100 text-green-600" 
                              : isCurrentStep 
                              ? "bg-primary/20 text-primary"
                              : "bg-muted text-muted-foreground"
                          }`}>
                            {stepCompleted ? (
                              <CheckCircle size={12} />
                            ) : (
                              step.stepNumber
                            )}
                          </div>
                          <div className="flex-1">
                            <p className={`text-sm font-medium ${
                              isCurrentStep ? "text-primary" : ""
                            }`} data-testid={`text-step-title-${step.id}`}>
                              {step.title}
                            </p>
                            <p className="text-xs text-muted-foreground" data-testid={`text-step-time-${step.id}`}>
                              {step.estimatedTime} min
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
