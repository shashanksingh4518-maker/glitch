import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Play, Clock } from "lucide-react";
import type { Tutorial } from "@shared/schema";

interface TutorialStepProps {
  tutorial: Tutorial;
  isCompleted?: boolean;
  isCurrent?: boolean;
  showStepNumber?: boolean;
  "data-testid"?: string;
}

export default function TutorialStep({ 
  tutorial, 
  isCompleted = false, 
  isCurrent = false,
  showStepNumber = false,
  "data-testid": testId 
}: TutorialStepProps) {
  const stepClasses = `tutorial-step transition-all duration-300 cursor-pointer ${
    isCurrent ? "border-2 border-accent/20 bg-accent/5" : ""
  } ${isCompleted ? "opacity-75" : ""}`;

  return (
    <Link href={`/tutorials/${tutorial.id}`}>
      <Card className={stepClasses} data-testid={testId}>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isCompleted 
                ? "bg-green-100" 
                : isCurrent 
                ? "bg-accent/10"
                : "bg-muted"
            }`}>
              {isCompleted ? (
                <CheckCircle className="text-green-600" size={20} />
              ) : isCurrent ? (
                <Play className="text-accent" size={16} />
              ) : (
                <span className="text-muted-foreground text-sm">
                  {showStepNumber ? tutorial.stepNumber : "•"}
                </span>
              )}
            </div>
            <div className="flex-1">
              <h4 className={`font-medium ${isCurrent ? "text-accent" : ""}`} data-testid={`text-tutorial-title-${tutorial.id}`}>
                {tutorial.title}
              </h4>
              <p className="text-sm text-muted-foreground" data-testid={`text-tutorial-description-${tutorial.id}`}>
                {tutorial.description}
              </p>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Clock size={14} />
              <span data-testid={`text-tutorial-time-${tutorial.id}`}>{tutorial.estimatedTime} min</span>
              {isCurrent && (
                <span className="text-sm font-medium text-accent ml-2" data-testid={`text-tutorial-status-${tutorial.id}`}>
                  In Progress
                </span>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
