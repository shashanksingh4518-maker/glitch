import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { LucideIcon } from "lucide-react";

interface ProgressCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  iconColor?: string;
  "data-testid"?: string;
}

export default function ProgressCard({ 
  title, 
  value, 
  icon: Icon, 
  iconColor = "text-primary",
  "data-testid": testId 
}: ProgressCardProps) {
  return (
    <Card data-testid={testId}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground" data-testid={`text-${testId}-title`}>
              {title}
            </p>
            <p className="text-2xl font-bold" data-testid={`text-${testId}-value`}>
              {value}
            </p>
          </div>
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon className={iconColor} size={20} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
