import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Search, 
  GraduationCap, 
  Bookmark, 
  TrendingUp, 
  User,
  Puzzle
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Browse Games", href: "/games", icon: Search },
  { name: "My Learning", href: "/learning", icon: GraduationCap },
  { name: "Bookmarks", href: "/bookmarks", icon: Bookmark },
  { name: "Progress", href: "/progress", icon: TrendingUp },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar-main">
      {/* Logo */}
      <div className="p-6 border-b border-border" data-testid="sidebar-header">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Puzzle className="text-primary-foreground" size={20} />
          </div>
          <div>
            <h1 className="text-xl font-bold" data-testid="text-app-title">GameMaster</h1>
            <p className="text-sm text-muted-foreground" data-testid="text-app-tagline">Learn • Play • Master</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 p-4" data-testid="sidebar-navigation">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <li key={item.name}>
                <Link 
                  href={item.href}
                  className={cn(
                    "flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors",
                    isActive 
                      ? "bg-primary text-primary-foreground" 
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                  data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <Icon size={20} />
                  <span>{item.name}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      
      {/* User Profile */}
      <div className="p-4 border-t border-border" data-testid="sidebar-user">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
            <User className="text-muted-foreground" size={20} />
          </div>
          <div className="flex-1">
            <p className="font-medium" data-testid="text-username">Alex Johnson</p>
            <p className="text-sm text-muted-foreground" data-testid="text-learning-progress">Learning Progress: 67%</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
