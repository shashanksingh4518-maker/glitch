import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import type { Game } from "@shared/schema";

interface GameCardProps {
  game: Game;
  "data-testid"?: string;
}

export default function GameCard({ game, "data-testid": testId }: GameCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "beginner":
        return "bg-primary/10 text-primary";
      case "intermediate":
        return "bg-accent/10 text-accent";
      case "advanced":
        return "bg-red-100 text-red-600";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Link href={`/games/${game.id}`}>
      <Card 
        className="game-card cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
        data-testid={testId}
      >
        <div className="overflow-hidden rounded-t-lg">
          <img 
            src={game.imageUrl || ""} 
            alt={game.title}
            className="w-full h-40 object-cover transition-transform duration-300 hover:scale-105"
            data-testid={`img-game-${game.id}`}
          />
        </div>
        <CardContent className="p-4">
          <h3 className="font-semibold mb-1" data-testid={`text-game-title-${game.id}`}>
            {game.title}
          </h3>
          <p className="text-sm text-muted-foreground mb-2" data-testid={`text-game-info-${game.id}`}>
            {game.category} • {game.playerCount}
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1">
              <div className="flex text-yellow-400 text-sm">
                {Array.from({ length: game.rating ?? 0 }).map((_, i) => (
                  <Star key={i} size={12} fill="currentColor" />
                ))}
              </div>
              <span className="text-sm text-muted-foreground" data-testid={`text-game-rating-${game.id}`}>
                {game.rating}.0
              </span>
            </div>
            <Badge 
              className={getDifficultyColor(game.difficulty)}
              data-testid={`badge-game-difficulty-${game.id}`}
            >
              {game.difficulty}
            </Badge>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
